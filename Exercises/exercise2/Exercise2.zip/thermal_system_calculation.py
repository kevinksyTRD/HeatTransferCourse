"""This module contains useful functions and classes for thermal system calculation

Symbols:
    h: convection_heat_transfer_coeffient [W/m2K]
    k: thermal conductivity [W/mK]
    r: radius [m]
    cp: specific heat capacity at constant pressure [J/kgK]
    temp: temperature [degC or K]
"""
import logging
from abc import ABC, abstractmethod
from enum import Enum, auto, unique
from functools import cached_property
from typing import Union, Tuple, NamedTuple

import numpy as np
from CoolProp.CoolProp import PropsSI

# Define logger
logger = logging.getLogger('thermal_system_calculation')
logger.setLevel(logging.INFO)

ch = logging.StreamHandler()
ch.setLevel(logging.INFO)

formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(formatter)

logger.addHandler(ch)

Numeric = Union[float, np.ndarray]
GRAVITY = 9.81


def get_heat_flux_by_conduction(
        temperature_from: Numeric,
        temperature_to: Numeric,
        thickness: Numeric,
        thermal_conductivity: Numeric,
) -> Numeric:
    """Returns heat flux [W/m2] by conduction from a section of material to another"""
    return thermal_conductivity * (temperature_from - temperature_to) / thickness


def get_heat_flux_by_convection(h: Numeric, temp_from: Numeric, temp_to: Numeric) -> float:
    """Returns heat flux [W/m2] by convection from a surface of a temperature (temp_from) to the
    fluid with another temperature (temp_to) for the given heat convection coefficient (alpha)"""
    return h * (temp_from - temp_to)


###################################################################################################
# Exercise 2

def get_thermal_resistance_cylinder(
        radius: Numeric,
        wall_thickness: Numeric,
        thermal_conductivity: Numeric,
        length: Numeric
) -> Numeric:
    """Returns thermal resistance [m2K/W] for a cylinder"""
    # Your code here
    return # Your code here


@unique
class TipBoundaryConditionForFin(Enum):
    Convection = auto()
    Adiabatic = auto()
    Temperature = auto()
    Long = auto()


class FinConfiguration(NamedTuple):
    perimeter: float
    area_cross_section: float
    length: float


def get_heat_transfer_1D_fin_with_uniform_cross_section(
        x: Numeric,
        temp_base: Numeric,
        temp_surr: Numeric,
        fin_configuration: FinConfiguration,
        h: Numeric,
        k: Numeric,
        boundary_condition: TipBoundaryConditionForFin,
        temp_tip: Numeric = None
) -> Tuple[Numeric, Numeric]:
    """Returns the heat transfer rate for the 1D find with a uniform cross section"""
    # Your code here
    return heat_transfer_rate, temp


# CoolProp related classes, functions

@unique
class Fluid(Enum):
    WATER = auto()
    AIR = auto()
    AMMONIA = auto()
    CO2 = auto()
    H2 = auto()
    NITROGEN = auto()
    OXYGEN = auto()
    R134A = auto()
    R143A = auto()
    R407C = auto()


@unique
class ThermodynamicState(Enum):
    PRESSURE = 'P'
    TEMPERATURE = 'T'
    SATURATION = 'Q'


@unique
class Properties(Enum):
    SPECIFIC_HEAT_CAPACITY_CONSTANT_PRESSURE = 'C'
    SPECIFIC_HEAT_CAPACITY_CONSTANT_VOLUME = 'CVMASS'
    GAS_CONSTANT_MOL = 'GAS_CONSTANT'
    DENSITY = 'D'
    CRITICAL_TEMPERATURE = 'Tcrit'
    RELATIVE_HUMIDITY = 'R'
    SPECIFIC_ENTHALPY = 'H'
    SPECIFIC_ENTROPY = 'S'
    SPECIFIC_INTERNAL_ENERGY = 'U'
    THERMAL_CONDUCTIVITY = 'CONDUCTIVITY'
    DYNAMIC_VISCOSITY = 'VISCOSITY'
    EXPANSION_COEFFICIENT_ISOBARIC = 'ISOBARIC_EXPANSION_COEFFICIENT'


@unique
class NonCircularCylinderGeometry(Enum):
    SQUARE_FLAT = auto()
    SQUARE_OBLIQUE = auto()
    HEXAGON_FLAT = auto()
    HEXAGON_OBLIQUE = auto()
    VERTICAL_FLAT_FRONT = auto()
    VERTICAL_FLAT_BACK = auto()


@unique
class TubeBankArrangement(Enum):
    Aligned = auto()
    Staggered = auto()


class TubeBankConfiguration(NamedTuple):
    arrangement: TubeBankArrangement
    vertical_spacing: float
    horizontal_spacing: float
    number_rows: float
    number_tubes_each_row: float

    def get_maximum_velocity(self, velocity: float, diameter: float):
        # Your code here

    @property
    def number_tubes_total(self):
        return self.number_rows * self.number_tubes_total


class FluidState:
    """Class for fluid state"""

    def __init__(
            self,
            fluid: Fluid,
            pressure_pa: Numeric = 101325,
            temp_k: Numeric = 300,
            characteristic_length: Numeric = None
    ):
        """Constructor for the class"""
        self.fluid = fluid.name
        self.pressure_pa = pressure_pa
        self.temp_k = temp_k
        self.characteristic_length = characteristic_length

    @cached_property
    def k(self):
        """Returns thermal conductivity in W/mK"""
        return PropsSI(
            Properties.THERMAL_CONDUCTIVITY.value,
            ThermodynamicState.PRESSURE.value, self.pressure_pa,
            ThermodynamicState.TEMPERATURE.value, self.temp_k,
            self.fluid
        )

    @cached_property
    def dynamic_viscosity(self):
        """Returns dynamic viscosity in Pa-s"""
        return PropsSI(
            Properties.DYNAMIC_VISCOSITY.value,
            ThermodynamicState.PRESSURE.value, self.pressure_pa,
            ThermodynamicState.TEMPERATURE.value, self.temp_k,
            self.fluid
        )

    @cached_property
    def density(self):
        """Returns density kg/m3"""
        return PropsSI(
            Properties.DENSITY.value,
            ThermodynamicState.PRESSURE.value, self.pressure_pa,
            ThermodynamicState.TEMPERATURE.value, self.temp_k,
            self.fluid
        )

    @cached_property
    def cp(self):
        """Returns specific heat capacity at constant pressure"""
        return PropsSI(
            Properties.SPECIFIC_HEAT_CAPACITY_CONSTANT_PRESSURE.value,
            ThermodynamicState.PRESSURE.value, self.pressure_pa,
            ThermodynamicState.TEMPERATURE.value, self.temp_k,
            self.fluid
        )

    @cached_property
    def expansion_coeff_isobaric(self):
        raise NotImplementedError("The method has not been implemented yet.")

    @property
    def prantdl_number(self) -> Numeric:
        """Returns Prantdl number"""
        # Your code here

    def get_nusselt_number(self, h: Numeric) -> Numeric:
        """Returns Nusselt number for given characteristic length in m and convection heat transfer
        coefficient in W/m2K"""
        # Your code here

    def get_h_from_nusselt_number(self, nu: Numeric) -> Numeric:
        """Returns convection heat transfer coefficient in W/m2K for given Nusselt number"""
        # Your code here

    def get_reynolds_number(self, velocity: Numeric) -> Numeric:
        """Returns reynolds number for given velocity"""
        # Your code here


class Convection(ABC):
    """Class for convection phenomenum"""

    def __init__(
            self,
            temp_surface: Numeric,
            temp_infinity: Numeric,
            fluid: Fluid,
            characteristic_length,
            pressure_pa: Numeric = 101325
    ):
        """Constructor for the class"""
        self.temp_surface = temp_surface
        self.temp_infinity = temp_infinity
        self.pressure_pa = pressure_pa
        self.fluid_state = FluidState(
            fluid=fluid,
            pressure_pa=pressure_pa,
            temp_k=np.mean([self.temp_surface, self.temp_infinity]),
            characteristic_length=characteristic_length
        )

    @property
    def prantdl_number(self):
        return self.fluid_state.prantdl_number

    @property
    @abstractmethod
    def nusselt_number(self):
        """Returns the nusselt number"""
        pass

    @property
    def h(self):
        """Returns h from a nusselt number"""
        # Your code here
        return h

    def get_heat_transfer_rate(self, area: Numeric):
        # Your code here
        return heat_transfer_rate


class ForcedConvection(Convection, ABC):
    """Abstract Class for forced convection"""

    def __init__(self, velocity: Numeric, *args, **kwargs):
        """Constructor for the class"""
        super().__init__(*args, **kwargs)
        self.velocity = velocity

    @property
    def reynolds_number(self):
        return self.fluid_state.get_reynolds_number(self.velocity)


class ForcedConvectionFlatPlateIsothermSurface(ForcedConvection):
    """Class for forced convection for flat plate """
    _REYNOLDS_NUMBER_AT_TRANSITION = 500000

    @property
    def critical_length(self) -> float:
        """returns the critical length at which transition from laminar to turbulent flow happens"""
        # Your code here
        return critical_length
    @property
    def critical_length_ratio(self) -> float:
        """Returns the ratio of critical length to the characteristic length"""
        # Your code here
        return critical_length_ratio

    @property
    def nusselt_number(self):
        """Returns a Nusselt number"""
        # Your code here
        return nusselt_number


class ForcedConvectionCylinderCrossFlow(ForcedConvection):
    """Class for forced convection for a circular cylinder in cross flow"""

    @property
    def nusselt_number(self):
        """Returns a Nusselt number by Churchill and Bernstein equation"""
        if #:
            logger.warning("The method used here may not be valid because the "
                           "the flow is not in the valid condition")
        # Your code here
        return nusselt_number


class ForcedConvectionNonCircularCylinderCrossFlow(ForcedConvection):
    """Class for forced convection for a non-circular cylinder in cross flow"""

    def __init__(self, geometry: NonCircularCylinderGeometry, *args, **kwargs):
        """Constructor"""
        super().__init__(*args, **kwargs)
        self.geometry = geometry

    @property
    def nusselt_number(self):
        """Returns a Nusselt number"""
        # Your code here
        return nusselt_number


class ForcedConvectionTubeBanksCrossFlow(ForcedConvection):
    """Class for forced convection for banks of tubes in cross flow"""

    def __init__(self, configuration: TubeBankConfiguration, *args, **kwargs):
        """Constructor"""
        super().__init__(*args, **kwargs)
        self.configuration = configuration

    @property
    def correction_factor(self):
        # Your code here
        return correction_factor
    @property
    def reynolds_number(self):
        """Returns the Reynolds number depending the maximum velocity through the banks"""
        # Your code here
        return reynolds_number

    @property
    def prantdl_number_surface(self):
        """Returns the prandtl number at the surface"""
        # Your code here
        return fluid_state_surface.prantdl_number

    @property
    def nusselt_number(self):
        """Returns a Nusselt number"""
        # Your code here
        return nusselt_number

    @property
    def temp_out(self):
        # Your code here
        return temp_out

    @property
    def log_mean_temperature_difference(self):
        # Your code here
        return log_mean_temperature_difference

    def get_heat_transfer_rate(self, length: Numeric):
        """Returns the heat transfer rate"""
        # Your code here
        return heat_transfer_rate
